#!/usr/bin/python

from Main import *

def eval(n): # n = 100, s = 27
	adivinar(42) # Regresa 1
	adivinar(32) # Regresa 1
	adivinar(22) # Regresa -1
	adivinar(28) # Regresa 1
	adivinar(27) # Regresa 0

	responder(27) # Envia respuesta; termina ejecucion
