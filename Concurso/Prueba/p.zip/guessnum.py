#!/usr/bin/python

from Main import *

# Funciones disponibles:
#   adivinar(i) (o guess(i))

def eval(n):

	# FIXME

	# Envia respuesta; termina ejecucion
	responder(0)
	#answer(0)
