import java.util.*;
import java.math.*;

class guessnum {

    // Bindings a funciones en la clase Main

    private static int adivinar(int i) {
        return Main.adivinar(i);
    }

    private static int guess(int i) {
        return Main.guess(i);
    }

    private static void responder(int i) {
        Main.responder(i);
    }

    private static void answer(int i) {
        Main.answer(i);
    }

    // Funciones disponibles:
    //   adivinar(i) (o guess(i))

    public static void eval(int n) {

        // FIXME

        // Envía respuesta; termina ejecución
        responder(0);
        //answer(0);

    }


}
